sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sm.com.SAPUI5Git.controller.View1", {
		onInit: function () {

		}
	});
});