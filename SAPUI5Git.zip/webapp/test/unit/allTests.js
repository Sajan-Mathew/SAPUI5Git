sap.ui.define([
	"sm/com/SAPUI5Git/test/unit/controller/View1.controller"
], function () {
	"use strict";
});