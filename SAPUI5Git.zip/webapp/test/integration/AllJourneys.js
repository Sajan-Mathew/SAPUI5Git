/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"sm/com/SAPUI5Git/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"sm/com/SAPUI5Git/test/integration/pages/View1",
	"sm/com/SAPUI5Git/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "sm.com.SAPUI5Git.view.",
		autoWait: true
	});
});